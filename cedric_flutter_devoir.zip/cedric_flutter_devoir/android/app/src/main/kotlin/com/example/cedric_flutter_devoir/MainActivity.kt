package com.example.cedric_flutter_devoir

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
